import tkinter.messagebox
import tkinter
root = tkinter.Tk()
root.withdraw() #****实现主窗口隐藏
root.update()
tkinter.messagebox.showinfo('提示',' 实现主窗口隐藏withdraw!')
